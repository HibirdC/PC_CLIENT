#!/usr/bin/env bash

set -e -x

sudo apt-get update
